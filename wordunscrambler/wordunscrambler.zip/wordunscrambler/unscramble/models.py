from django.db import models

# Create your models here.
class Words (models.Model):
    dictionary = models.TextField()
    def __str__(self):
        return str(self.dictionary)