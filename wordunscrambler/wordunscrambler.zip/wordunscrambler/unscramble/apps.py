from django.apps import AppConfig


class UnscrambleConfig(AppConfig):
    name = 'unscramble'
