from unscramble.models import Words

def unscramble(word):
    query = Words.objects.filter(id='1').values_list('dictionary', flat=True)
    dict_list = []
    for wrd in query:
        dict_list.append(wrd.split())
    dict_list = dict_list[0]
    countToMatch = len(word)
    matchedWords = []
    finalMatches = []
    for words in dict_list:
        count = 0
        for x in word:
            if x in words:
                count += 1
            if count == countToMatch:
                matchedWords.append(words)
                break
    for matchedWord in matchedWords:
        if len(matchedWord) == len(word):
            finalMatches.append(matchedWord)
    return finalMatches