from django.views.generic.detail import View, DetailView
from .models import Words
from django.shortcuts import *
from unscramble.modules import unscramble

def scramble(request):
    if request.method == "POST":
        word = request.POST['word']
        finalMatches = unscramble.unscramble(word)
        context = {'word': word, 'matched': finalMatches}
        return render(request, 'scram.html',
                      {'context': context})
    else:
        return render(request, 'scram.html', {})
