
from django.conf.urls import url
from django.contrib import admin
from unscramble import views as scram_views
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^scram', scram_views.scramble, name='scram'),
    url(r'^', scram_views.scramble, name='home')
]
